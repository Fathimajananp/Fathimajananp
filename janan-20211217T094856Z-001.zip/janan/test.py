def diff(a,b):
    result=a-b
    return result
